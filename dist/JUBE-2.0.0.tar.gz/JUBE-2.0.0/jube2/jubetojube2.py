"""The JubeXMLConverter class provide support to convert jube file to the new format"""

from __future__ import (print_function,
                        unicode_literals,
                        division,
                        )

import xml.etree.ElementTree as ET
import sys
import os
import jube2.parameter

#import jube2.benchmark

class JubeXMLConverter(object):
    valid_tags = ["bench", "benchmark", "prepare", "compile",
                  "execution", "tasks", "params", "verify", "analyse"]
    valid_files = ["compile.xml", "execute.xml", "analyse.xml", "prepare.xml", "result.xml", "verify.xml", "platform.xml"]
    
    def __init__(self, main_file, main_dir="./"):
        self._main_file = main_file
        self._main_dir = main_dir
        self._main_xml_file = self._main_dir + main_file
    
        self._compile_xml_file  = self._main_dir + "compile.xml"
        self.file_availability(self._compile_xml_file)
        
        self._execute_xml_file  = self._main_dir + "execute.xml"
        self.file_availability(self._execute_xml_file)
        
        self._analyse_xml_file  = self._main_dir + "analyse.xml"
        self.file_availability(self._analyse_xml_file)
        
        self._prepare_xml_file  = self._main_dir + "prepare.xml"
        self.file_availability(self._prepare_xml_file)
        
        self._result_xml_file   = self._main_dir + "result.xml"
        self.file_availability(self._result_xml_file)
        
        self._verify_xml_file   = self._main_dir + "verify.xml"
        self.file_availability(self._verify_xml_file)
        
        self._platform_xml_file = self._main_dir + "platform.xml"
        self.file_availability(self._platform_xml_file)

# Setup XML trees
        self._platform_xml_root  = self.build_xml_tree(self._platform_xml_file)
        self._main_xml_file_root = self.build_xml_tree(self._main_xml_file)
        self._compile_xml_root   = self.build_xml_tree(self._compile_xml_file)
        self._execute_xml_root   = self.build_xml_tree(self._execute_xml_file)
        self._analyse_xml_root   = self.build_xml_tree(self._analyse_xml_file)
        self._prepare_xml_root   = self.build_xml_tree(self._analyse_xml_file)
        self._verify_xml_root    = self.build_xml_tree(self._verify_xml_file)
        self._result_xml_root    = self.build_xml_tree(self._result_xml_file)
        
        self._root_parameters = jube2.parameter.Parameterset() # set in extract parameter
        self._gathered_benchmarks = self.gather_benchmarks()
        self._global_parameters = jube2.parameter.Parameterset() # set in extract_parameter

    def file_availability(self, filename):
            if(os.path.isfile(filename)):
                return True
            elif(os.path.basename(filename) == "platform.xml"):
                self._platform_xml_file = self._main_dir + "../../platform/platform.xml"
                if (os.path.isfile(self._platform_xml_file)):
                    return True
                else:
                    message = self._platform_xml_file + " doesn't exist"
                    print ("Are you here???")
                    sys.exit(message)
            message = filename + " doesn't exist"
            sys.exit(message)
            return False
                            
        
        
    def print_xml(self):
        print(self._main_file)
        print(self._compile_xml_file)
        
    def build_xml_tree(self, filename):
        tree = ET.parse(filename)

        # Check compatible terminal encoding: In some cases, the terminal env.
        # only allow ascii based encoding, print and filesystem operation will
        # be broken if there is a special char inside the input file.
        # In such cases the encode will stop, using an UnicodeEncodeError
        try:
            xml = ET.tostringlist(tree.getroot(), encoding="UTF-8")
            for line in xml:
                line.decode("UTF-8").encode(sys.getfilesystemencoding())
        except UnicodeEncodeError as uee:
            raise ValueError("Your terminal only allow '{0}' encoding. {1}"
                             .format(sys.getfilesystemencoding(), str(uee)))

        return tree.getroot()
    
    def gather_benchmarks(self):
        gathered_benchmarks = []
        for child in self._main_xml_file_root:
            gathered_benchmarks.append(child)
        return gathered_benchmarks
 
# Read in parameter from jube main file
    def parameter_feed(self, item):
        parameter_set = jube2.parameter.Parameterset()
        for child in self._gathered_benchmarks[0].findall(item):
            for k, v in child.attrib.items():
                if k == "cname":
                    k = k + "_" + item
                p = jube2.parameter.StaticParameter(k, v)
                parameter_set.add_parameter(p)
        
        parameter_set.parameter_substitution(self._root_parameters)
        self._global_parameters.add_parameterset(parameter_set)

    def extract_parameter(self):
        # Extract parameter set in bench
        for k,v in self._main_xml_file_root.attrib.items():
            p = jube2.parameter.StaticParameter(k,v)
            self._root_parameters.add_parameter(p)
            
        
        for item in self.valid_tags:
            self.parameter_feed(item)
                
# Figure out the needed parameter set from platform file
        d = self._main_xml_file_root.attrib
        platform_spec = d['platform']

        for child in self._platform_xml_root:
            for deep in child.findall('params'):
                d_compare = child.attrib
                matched_platform = d_compare['name']
                if (matched_platform == platform_spec):
                    for k,v in deep.attrib.items():
                        p = jube2.parameter.StaticParameter(k,v)
                        self._global_parameters.add_parameter(p)
        
# 
        print(self._global_parameters)
                    
        
 
            
  
    
    
    
if __name__ == "__main__":
#     main_dir = "/home11/schnural/tmp/jube2jube2-tests/ior/"
#     jube_main_file = "jube-DEEP-small.xml"
#     main_dir = "/home11/schnural/tmp/jube2jube2-tests/mdtest/"
#     jube_main_file = "jube-DEEP.xml"
    main_dir = "/home/zam/schnural/SVN_PRACE_TRAC/benchmark/applications/gromacs/"
    jube_main_file = "nbench-Cray-XT4-Louhi.xml"
    
    j2j2 = JubeXMLConverter(jube_main_file, main_dir)
    j2j2.print_xml()
    j2j2.extract_parameter()
