"""jube2 package"""
