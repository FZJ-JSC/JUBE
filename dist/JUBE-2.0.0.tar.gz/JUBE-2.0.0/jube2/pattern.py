"""Patternset definition"""

# #############################################################################
# #  JUBE Benchmarking Environment                                           ##
# #  http://www.fz-juelich.de/jsc/jube                                       ##
# #############################################################################
# #  Copyright (c) 2008-2014                                                 ##
# #  Forschungszentrum Juelich, Juelich Supercomputing Centre                ##
# #                                                                          ##
# #  See the file LICENSE in the package base directory for details          ##
# #############################################################################

from __future__ import (print_function,
                        unicode_literals,
                        division)

import jube2.parameter
import xml.etree.ElementTree as ET

REDUCE_OPTIONS = set(
    ["first", "last", "min", "max", "avg", "sum", "cnt", "all"])


class Patternset(object):

    """A Patternset stores a set of pattern and derived pattern."""

    def __init__(self, name=""):
        self._name = name
        self._pattern = jube2.parameter.Parameterset("pattern")
        self._derived_pattern = jube2.parameter.Parameterset("derived_pattern")

    def add_pattern(self, pattern):
        """Add a additional pattern to the patternset. Existing pattern using
        the same name will be overwritten"""
        if pattern.derived:
            if pattern in self._pattern:
                self._pattern.delete_parameter(pattern)
            self._derived_pattern.add_parameter(pattern)
        else:
            if pattern in self._derived_pattern:
                self._derived_pattern.delete_parameter(pattern)
            self._pattern.add_parameter(pattern)

    @property
    def pattern_storage(self):
        """Return the pattern storage"""
        return self._pattern

    @property
    def derived_pattern_storage(self):
        """Return the derived pattern storage"""
        return self._derived_pattern

    def etree_repr(self):
        """Return etree object representation"""
        patternset_etree = ET.Element('patternset')
        patternset_etree.attrib["name"] = self._name
        for pattern in self._pattern:
            patternset_etree.append(
                pattern.etree_repr())
        for pattern in self._derived_pattern:
            patternset_etree.append(
                pattern.etree_repr())
        return patternset_etree

    def add_patternset(self, patternset):
        """Add all pattern from given patternset to the current one"""
        self._pattern.add_parameterset(patternset.pattern_storage)
        self._derived_pattern.add_parameterset(
            patternset.derived_pattern_storage)

    def pattern_substitution(self, parametersets=None):
        """Run pattern substitution using additional parameterset"""
        if parametersets is None:
            parametersets = list()
        self._pattern.parameter_substitution(
            additional_parametersets=parametersets,
            final_sub=True)

    def derived_pattern_substitution(self, parametersets=None):
        """Run derived pattern substitution using additional parameterset"""
        if parametersets is None:
            parametersets = list()
        self._derived_pattern.parameter_substitution(
            additional_parametersets=parametersets,
            final_sub=True)

    @property
    def name(self):
        """Get patternset name"""
        return self._name

    def copy(self):
        """Returns a copy of the Parameterset"""
        new_patternset = Patternset(self._name)
        new_patternset.add_patternset(self)
        return new_patternset

    def is_compatible(self, patternset):
        """Two Patternsets are compatible, if all pattern storages are
        compatible"""
        return self.pattern_storage.is_compatible(
            patternset.pattern_storage) and \
            self.pattern_storage.is_compatible(
                patternset.derived_pattern_storage) and \
            self.derived_pattern_storage.is_compatible(
                patternset.derived_pattern_storage) and \
            self.derived_pattern_storage.is_compatible(
                patternset.pattern_storage)

    def __repr__(self):
        return "Patternset: pattern:{} derived pattern:{}".format(
            dict([[pattern.name, pattern.value]
                  for pattern in self._pattern]),
            dict([[pattern.name, pattern.value]
                  for pattern in self._derived_pattern]))

    def __contains__(self, pattern):
        if isinstance(pattern, Pattern):
            if pattern.name in self._pattern:
                return pattern.is_equivalent(
                    self._pattern[pattern.name])
            elif pattern.name in self._derived_pattern:
                return pattern.is_equivalent(
                    self._derived_pattern[pattern.name])
            else:
                return False
        elif isinstance(pattern, str):
            return (pattern in self._pattern) or \
                   (pattern in self._derived_pattern)
        else:
            return False

    def __getitem__(self, name):
        """Returns pattern given by name. Is pattern not found, None will
        be returned"""
        if name in self._pattern:
            return self._pattern[name]
        elif name in self._derived_pattern:
            return self._derived_pattern[name]
        else:
            return None


class Pattern(jube2.parameter.StaticParameter):

    """A pattern can be used to scan a result file, using regular expression,
    or to represent a derived pattern."""

    def __init__(self, name, value, pattern_mode="pattern",
                 content_type="string", unit="", reduce_option=None):
        self._derived = pattern_mode != "pattern"

        if not self._derived:
            pattern_mode = "text"

        jube2.parameter.StaticParameter.__init__(
            self, name, value, parameter_type=content_type,
            parameter_mode=pattern_mode)

        self._unit = unit
        if reduce_option is None:
            self._reduce_option = set(["first"])
        else:
            self._reduce_option = reduce_option
        if "all" in self._reduce_option:
            self._reduce_option = self._reduce_option.union(REDUCE_OPTIONS)

    @property
    def derived(self):
        """pattern is a derived pattern"""
        return self._derived

    @property
    def reduce_option(self):
        """Get pattern reduce option"""
        return self._reduce_option

    @property
    def content_type(self):
        """Return pattern type"""
        return self._type

    @property
    def unit(self):
        """Return unit"""
        return self._unit

    def substitute_and_evaluate(self, parametersets=None,
                                final_sub=False):
        """Substitute all variables inside the pattern value by using the
        parameter inside the given parameterset and additional_parameterset.
        final_sub marks the last substitution.

        Return the new pattern and a boolean value which represent a change
        of value
        """
        param, changed = \
            jube2.parameter.StaticParameter.substitute_and_evaluate(
                self, parametersets, final_sub)

        if changed:
            # Convert parameter to pattern
            if not self.derived:
                pattern_mode = "pattern"
            else:
                pattern_mode = "text"
            pattern = Pattern(param.name, param.value, pattern_mode,
                              param.parameter_type, self._unit,
                              self._reduce_option)
            pattern.based_on = param.based_on
        else:
            pattern = param
        return pattern, changed

    def etree_repr(self, use_current_selection=False):
        """Return etree object representation"""
        pattern_etree = ET.Element('pattern')
        pattern_etree.attrib["name"] = self._name
        pattern_etree.attrib["type"] = self._type

        if not self._derived:
            pattern_etree.attrib["mode"] = "pattern"
        else:
            pattern_etree.attrib["mode"] = self._mode

        if self._unit != "":
            pattern_etree.attrib["unit"] = self._unit
        pattern_etree.attrib["reduce"] = \
            jube2.conf.DEFAULT_SEPARATOR.join(self._reduce_option)
        pattern_etree.text = self.value
        return pattern_etree

    def __repr__(self):
        return "Pattern({})".format(self.__dict__)


def get_jube_pattern():
    """Return jube internal patternset"""
    patternset = Patternset()
    # Pattern for integer number
    patternset.add_pattern(Pattern("jube_pat_int", r"([+-]?\d+)"))
    # Pattern for integer number, no ()
    patternset.add_pattern(Pattern("jube_pat_nint", r"(?:[+-]?\d+)"))
    # Pattern for floating point number
    patternset.add_pattern(
        Pattern("jube_pat_fp", r"([+-]?\d*\.?\d+(?:[eE][-+]?\d+)?)"))
    # Pattern for floating point number, no ()
    patternset.add_pattern(
        Pattern("jube_pat_nfp", r"(?:[+-]?\d*\.?\d+(?:[eE][-+]?\d+)?)"))
    # Pattern for word (all noblank characters)
    patternset.add_pattern(Pattern("jube_pat_wrd", r"(\S+)"))
    # Pattern for word (all noblank characters), no ()
    patternset.add_pattern(Pattern("jube_pat_nwrd", r"(?:\S+)"))
    # Pattern for blank space (variable length)
    patternset.add_pattern(Pattern("jube_pat_bl", r"(?:\s+)"))
    return patternset
