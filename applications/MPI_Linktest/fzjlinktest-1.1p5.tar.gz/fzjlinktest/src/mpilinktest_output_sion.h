/****************************************************************************
**  LinkTest                                                               **
*****************************************************************************
**  Copyright (c) 2008-2011                                                **
**  Forschungszentrum Juelich, Juelich Supercomputing Centre               **
**                                                                         **
**  See the file COPYRIGHT in the package base directory for details       **
****************************************************************************/
#ifndef MPILINKTEST_OUTPUT_SION_H
#define MPILINKTEST_OUTPUT_SION_H
int linktest_output_sion_collect_local_data ( _linktest_spec *linktest_spec, _linktest_stat *linktest_stat,
					      char **buffer, long  *my_buffer_size);      

#endif
