/****************************************************************************
**  LinkTest                                                               **
*****************************************************************************
**  Copyright (c) 2008-2011                                                **
**  Forschungszentrum Juelich, Juelich Supercomputing Centre               **
**                                                                         **
**  See the file COPYRIGHT in the package base directory for details       **
****************************************************************************/
#ifndef MPILINKTEST_UTIL_MACHINE_H
#define MPILINKTEST_UTIL_MACHINE_H

long get_memusage();
int print_memusage(int i);

#endif
