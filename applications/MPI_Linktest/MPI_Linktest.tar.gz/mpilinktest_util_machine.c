/****************************************************************************
**  LinkTest                                                               **
*****************************************************************************
**  Copyright (c) 2008-2011                                                **
**  Forschungszentrum Juelich, Juelich Supercomputing Centre               **
**                                                                         **
**  See the file COPYRIGHT in the package base directory for details       **
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>


#ifdef LINKTEST_LINUX
#include <sys/times.h>
#include <sys/resource.h>

struct rusage rusagestr;
long get_memusage() {
  if (getrusage(RUSAGE_SELF, &rusagestr) != 0) {
    return -1;
  }
  
  /* printf("get_memusage: rusage.ru_maxrss=%10ld\n",rusagestr.ru_maxrss);  */
  return rusagestr.ru_maxrss;
} 

int print_memusage(int i)
{
  if (getrusage(RUSAGE_SELF, &rusagestr) != 0)
    return -1;

  printf("PE: %04d: MEMUSAGE: %12.8f\n",i, rusagestr.ru_maxrss / 1024.0);

  return 1;
} 

#else

long get_memusage() {
  return 0;
} 

int print_memusage(int i)
{
  printf("PE: %04d: MEMUSAGE: ???\n",i);
  return 1;
} 


#endif
