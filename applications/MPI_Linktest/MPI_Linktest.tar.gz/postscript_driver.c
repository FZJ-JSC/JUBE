/****************************************************************************
**  LinkTest                                                               **
*****************************************************************************
**  Copyright (c) 2008-2011                                                **
**  Forschungszentrum Juelich, Juelich Supercomputing Centre               **
**                                                                         **
**  See the file COPYRIGHT in the package base directory for details       **
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include "postscript_driver.h"



int PSplotrow (FILE *OUT, double *ptimings, int rank, int ntasks, double minval, double maxval, char *location, 
	       int do_range, double opt_mintime, double opt_maxtime) {
  int t;
  double col,val;
  double posx,posy,bheight,bwidth;
  char helpstr[256];
  double linewidth;
  double textheight;
  int printit=1;

  bheight=(double) PSMATH/ntasks;
  bwidth =(double) PSMATW/ntasks;
  textheight=0.6*bheight;
  if(textheight>10) textheight=10;
  posy=PSMATY+rank*bheight;
  linewidth=0.5;
  if(ntasks>32) linewidth=0.0;
  if(ntasks>1024) linewidth=0.0;

  frectgrey(OUT,PSMATX,posy,PSMATW,bheight,linewidth,0.9); 

  for(t=0;t<ntasks;t++) {
    
    if(do_range) {
      printit=((ptimings[t]<opt_mintime) || (ptimings[t]>opt_maxtime));
    }


    posx=PSMATX+t*bwidth;
    val=(ptimings[t]-minval)/(maxval-minval);
    col=nval2col(val);
    if(printit) {
      if(ptimings[t]>0) {
	frect(OUT,posx,posy,bwidth,bheight,linewidth,col);
      } else {
/* 	frectgrey(OUT,posx,posy,bwidth,bheight,linewidth,0.8); */
      }
      if(linewidth>0) {
	rect(OUT,posx,posy,bwidth,bheight,linewidth,0.1);
      }
    }
  }
  righttext(OUT,location,PSMATX+PSTEXTXOFF,posy+2,textheight);
  righttextrot(OUT,location,PSMATX+rank*bwidth+bwidth,PSMATY+PSTEXTYOFF,textheight);
  sprintf(helpstr,"%d",rank);
  text(OUT,helpstr,PSMATX+PSMATW+2,posy+2,textheight);
  textrot(OUT,helpstr,PSMATX+rank*bwidth+bwidth,PSMATY+PSMATH+2,textheight);
  return(1);
}


